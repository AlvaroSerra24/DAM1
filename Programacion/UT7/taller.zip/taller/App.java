package taller;

public class App {
	public static void main(String[] args) {
		Vehiculo misVehiculos[]=new Vehiculo[5];
		int nCoches=0,nMotos=0;
		misVehiculos[0]=new Moto("1234", "Yamaha", "YZF", 1000);
		misVehiculos[1]=new Coche("1234FFF", "Seat", "Ibiza", "Negro", 5);
		misVehiculos[2]=new Coche("3432RRR", "Alfa Romeo", "Mito", "Azul", 3);
		
		Cliente c=new Cliente("Marta", "Ruiz", "324343", "C/Mayor", 0, misVehiculos);
		System.out.println("Los vehículos de "+c.getNombre()+" son: ");
		for (int i = 0; i < c.getV().length; i++) {
			if(c.getV()[i]!=null) {
				System.out.println(c.getV()[i].getMatricula()+" "+c.getV()[i].getMarca()+" "+c.getV()[i].getModelo());
				if(c.getV()[i] instanceof Coche)
					nCoches++;
				if(c.getV()[i] instanceof Moto)
					nMotos++;
			}
		}
		
		System.out.println("Número de vehículos: "+(nCoches+nMotos));
		System.out.println("Número de coches: "+nCoches);
		System.out.println("Número de motos: "+nMotos);
		
		
	}
}
